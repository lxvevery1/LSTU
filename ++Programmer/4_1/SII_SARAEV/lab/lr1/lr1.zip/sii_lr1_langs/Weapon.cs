﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace sii_lr1
{
    [Serializable]
    public class Weapon
    {
        public int ID { get; private set; }
        public string Name { get; private set; }
        public double Probability { get; set; }
        public double NormalizedProbability { get; set; }

        public Weapon(int id, string name, double probability)
        {
            ID = id;
            Name = name;

            if (probability < 0 || probability > 1)
                throw new Exception("Probability is invalid (001)");

            Probability = probability;
        }

        public void ChangeProbability(double delta)
        {
            if (delta < -1 || delta > 1)
                throw new Exception("Change of Probability is invalid (002)");

            Probability += delta;

/*            if (Probability > 1)
                Probability = 1;
            if (Probability < 0)
                Probability = 0;*/
        }

        public string ProbabilityToString()
        {
            return Name + "\t " + Probability * 100 + "%";
        }

        public string NormProbabilityToString()
        {
            return Name + "\t " + NormalizedProbability * 100 + "%";
        }

        public double NormalizeProbability(List<double> allProbs)
        {
            // Вычисляем сумму всех вероятностей
            double totalSum = allProbs.Sum();

            // Проверяем, что сумма больше 0, чтобы избежать деления на 0
            if (totalSum > 0)
            {
                // Нормализуем каждую вероятность путем деления на общую сумму
                for (int i = 0; i < allProbs.Count; i++)
                {
                    allProbs[i] = allProbs[i] / totalSum;
                    Console.WriteLine(allProbs[i]);
                }
            }

            NormalizedProbability = allProbs[ID-1];
            return NormalizedProbability;
        }

        public void NormalizeProbabilityWrapper(List<double> allProbs)
        {
            NormalizedProbability = NormalizeProbability(allProbs);
            // NormalizedProbability = allProbs.Sum();
        }
    }
}
