﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace sii_lr1
{
    [Serializable]
    public class Weapons
    {
        public List<Weapon> weaps { get; private set; }

        public Weapons()
        {
            string json;
            FileStream fileStream = new FileStream("langs.json", FileMode.Open);
            StreamReader streamReader = new StreamReader(fileStream);
            json = streamReader.ReadToEnd();
            streamReader.Close();
            fileStream.Close();
            weaps = JsonConvert.DeserializeObject<List<Weapon>>(json);
        }
    }
}
