﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace sii_lr1
{
    public partial class Form1 : Form
    {
        private Weapons weapons;
        private Answers answers;
        private List<ComboBox> combos = new List<ComboBox>();
        // private List<double> weaponStartProbabilities;
        private int[] selected = new int[10];

        public Form1()
        {
            InitializeComponent();

            weapons = new Weapons();
            answers = new Answers();
            SetUp();
        }


        public void SetUp()
        {
            combos.Add(comboBox1);
            combos.Add(comboBox2);
            combos.Add(comboBox3);
            combos.Add(comboBox4);
            combos.Add(comboBox5);
            combos.Add(comboBox6);
            combos.Add(comboBox7);
            combos.Add(comboBox8);
            combos.Add(comboBox9);
            combos.Add(comboBox10);

            for (int i = 0; i < answers.answers.Count; i++)
            {
                combos[answers.answers[i].QuestID - 1].Items.Add(answers.answers[i].Text);
            }

            /*weaponStartProbabilities = new List<double>(weapons.weaps.Count);
            for (int i = 0; i < weapons.weaps.Count; i++)
            {
                weaponStartProbabilities[i] = weapons.weaps[i].Probability;
            }*/
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex + 0;
            selected[0] = index;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox2.SelectedIndex + 2;
            selected[1] = index;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox3.SelectedIndex + 4;
            selected[2] = index;
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox4.SelectedIndex + 6;
            selected[3] = index;
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox5.SelectedIndex + 8;
            selected[4] = index;
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox6.SelectedIndex + 16;
            selected[5] = index; ;
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox7.SelectedIndex + 18;
            selected[6] = index;
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox8.SelectedIndex + 20;
            selected[7] = index;
        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox9.SelectedIndex + 24;
            selected[8] = index;
        }

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox10.SelectedIndex + 26;
            selected[9] = index;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*for (int i = 0; i < weapons.weaps.Count; i++)
            {
                weapons.weaps[i].Probability = weaponStartProbabilities[i];
            }*/


            List<double> allProbs = new List<double>();

            foreach (var weapon in weapons.weaps)
                allProbs.Add(weapon.Probability);

            for (int i = 0; i < selected.Length; i++)
            {
                answers.answers[selected[i]].Enter(weapons);
            }

            string result = "";

            foreach (var item in weapons.weaps)
            {
                item.NormalizeProbability(allProbs);
                result += item.NormProbabilityToString() + Environment.NewLine;
            }

            MessageBox.Show(result, "Результат");

        }
    }
}
